🇬🇧 EN — Test data helper
1) TestData_Polinom_2.xlsx

Model: full 2nd-order polynomial with two factors (x1, x2).
Expected: all coefficients = 1 (const, x1, x2, x1², x2², x1·x2).
Tip: use Custom terms = full poly2.

2) TestData_Polinom_3.xlsx

Model: 2nd-order polynomial (test of term selection / stability).
Expected: all coefficients = 1.
Tip: if Auto misses a term, set Custom with full poly2.

3) TestData_Himmelblaut.xlsx (Himmelblau function)

Custom terms required: include 4th-order terms x1^4, x2^4.
Expected coefficients (Custom):

const = 1.720434463

x1 = -0.132115514

x2 = -0.221352995

x1^2 = -0.230340356

x2^2 = -0.154464055

x2^3 = -0.00145144

x1·x2 = -0.055270331

x1^4 = 0.01255169

x2^4 = 0.010459873

Quality: R² ≈ 0.9987.
Extremum search: expand variable bounds to [-5, 5].
In linear metric the function has 4 minima in this domain.
Important: for LOG / LOGIT models remember that “min/max” direction may flip depending on the transformation and target definition.
To find all local extrema, increase the number of search trials / start points.